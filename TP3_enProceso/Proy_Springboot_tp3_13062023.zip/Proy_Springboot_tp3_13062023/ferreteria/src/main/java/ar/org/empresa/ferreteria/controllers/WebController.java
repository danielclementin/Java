package ar.org.empresa.ferreteria.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.empresa.ferreteria.entities.Articulo;
import ar.org.empresa.ferreteria.entities.Cliente;
import ar.org.empresa.ferreteria.entities.Pedido;
import ar.org.empresa.ferreteria.repositories.ArticuloRepository;
import ar.org.empresa.ferreteria.repositories.ClienteRepository;
import ar.org.empresa.ferreteria.repositories.PedidoRepository;

@Controller
public class WebController {
    
    private ArticuloRepository articuloRepository=new ArticuloRepository();
    private ClienteRepository clienteRepository=new ClienteRepository();
    private PedidoRepository pedidoRepository=new PedidoRepository();

    private String mensajeArticulo="Ingrese un nuevo artículo";
    private String mensajeCliente="Ingrese un nuevo cliente";
    private String mensajePedido="Ingrese un nuevo pedido";

    @GetMapping("/")
    public String getIndex(){
        return "index";
    }

    @GetMapping("/articulos")
    public String getArticulos(@RequestParam(name="buscarNombreItem", required = false, defaultValue="") String buscarNombreItem,
                                 Model model){
        model.addAttribute("mensajeArticulo", mensajeArticulo);
        model.addAttribute("articulo", new Articulo());
        model.addAttribute("articulos", articuloRepository.getAll());
        model.addAttribute("likeNombreItem", articuloRepository.getLikeNombreItem(buscarNombreItem));
        return "articulos";
    }

    @GetMapping("/clientes")
    public String getClientes(@RequestParam(name="buscarApellido", required = false, defaultValue="") String buscarApellido,
                    Model model){
        model.addAttribute("mensajeCliente", mensajeCliente);
        model.addAttribute("cliente", new Cliente());
        model.addAttribute("likeApellido", clienteRepository.getLikeApellido(buscarApellido));
        model.addAttribute("clientes", clienteRepository.getAll());
        return "clientes";
    }

    @GetMapping("/pedidos")
    public String getPedidos(@RequestParam(name="buscarCodCliente", required = false, defaultValue="") int buscarCodCliente,
                    Model model){
        model.addAttribute("mensajePedido", mensajePedido);
        model.addAttribute("pedido", new Pedido());
        model.addAttribute("likeCodCliente", pedidoRepository.getByCodCliente(buscarCodCliente));
        model.addAttribute("pedidos", pedidoRepository.getAll());
        return "pedidos";
    }


    @PostMapping("/saveArticulo")
    public String save(@ModelAttribute Articulo articulo){
        try {
            articuloRepository.save(articulo);
            mensajeArticulo="Se guardo el artículo codArticulo: "+articulo.getCodArticulo();
        } catch (Exception e) {
            mensajeArticulo="Ocurrio un error";
        }
        return "redirect:articulos";
    }

    @PostMapping("/saveCliente")
    public String save(@ModelAttribute Cliente cliente){
        try {
            clienteRepository.save(cliente);
            mensajeCliente="Se guardo el cliente codCliente: "+cliente.getCodCliente();
        } catch (Exception e) {
            mensajeCliente="Ocurrio un error";
        }
        return "redirect:clientes";
    }

    @PostMapping("/savePedido")
    public String save(@ModelAttribute Pedido pedido){
        try {
            pedidoRepository.save(pedido);
            mensajePedido="Se guardo el pedido codPedido: "+pedido.getCodPedido();
        } catch (Exception e) {
            mensajePedido="Ocurrio un error";
        }
        return "redirect:pedidos";
    }
}
