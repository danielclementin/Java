package ar.org.empresa.ferreteria.test;

import ar.org.empresa.ferreteria.entities.Cliente;
import ar.org.empresa.ferreteria.entities.Articulo;
import ar.org.empresa.ferreteria.entities.Pedido;
import ar.org.empresa.ferreteria.enums.TipoEntrega;

import ar.org.empresa.ferreteria.repositories.ClienteRepository;
import ar.org.empresa.ferreteria.repositories.ArticuloRepository;
import ar.org.empresa.ferreteria.repositories.PedidoRepository;

public class TestRepository {
   public static void main(String[] args) {
        PedidoRepository pr=new PedidoRepository();
        Pedido pedido=new Pedido(1,4,1,54.00f,TipoEntrega.Envio,"2023-06-07");
        pr.save(pedido);
        System.out.println("Muestra en pantalla de pedido cargado");
        System.out.println(pedido);
        
        System.out.println("Impresión de todos los pedidos existentes");
        pr.getAll().forEach(System.out::println);


        System.out.println("***************Fin de impresión de impresión masiva**********");
        System.out.println("Impresión por codigo de pedido: 2");
        System.out.println(pr.getByCodPedido(2));
        System.out.println("******************************");
        System.out.println("Impresión de pedido por código de cliente: 4");
        System.out.println(pr.getByCodCliente(4));

         System.out.println("Impresión de clientes");

        ClienteRepository cr=new ClienteRepository();
        Cliente cliente=new Cliente(22,"Ernesto","Fernandez",
        "20236569","1165987841","Montes de Oca 2365",
        "1047","ernesto@hotmail.com");
        cr.save(cliente);
        System.out.println(cliente);

        System.out.println("******************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("******************************");
        System.out.println(cr.getByCodCliente(5));
        System.out.println("******************************");
        System.out.println("Impresión, busqueda de apellido que contengan *fe* ");
        cr.getLikeApellido("fe").forEach(System.out::println);


        ArticuloRepository ar=new ArticuloRepository();
        Articulo articulo=new Articulo(22,"Taladro neumático", "Tamaño máximo 1pulgada", 12500.50f);
        ar.save(articulo);
        System.out.println("Muestra en pantalla el articulo cargado");
        System.out.println(articulo);
        
        System.out.println("Impresión de todos los articulos existentes");
        ar.getAll().forEach(System.out::println);


        System.out.println("***************Fin de impresión de impresión masiva**********");
        System.out.println("Impresión por codigo de artículo: 5");
        System.out.println(ar.getByCodArticulo(5));
        System.out.println("******************************");
        System.out.println("Impresión, busqueda de nombre de Item que contengan *des* ");
        ar.getLikeNombreItem("des").forEach(System.out::println);
        
   } 
}
