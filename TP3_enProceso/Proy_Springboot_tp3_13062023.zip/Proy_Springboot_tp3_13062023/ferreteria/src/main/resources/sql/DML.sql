INSERT INTO articulos (codArticulo, nombreItem, descripcion, precioUnitario) 
VALUES (1,'Martillo', 'Martillo de acero', 249.99);

INSERT INTO articulos (codArticulo, nombreItem, descripcion, precioUnitario) 
VALUES (2,'Destornillador Phillips', 'Destornillador con punta Phillips', 149.99);

INSERT INTO articulos (codArticulo, nombreItem, descripcion, precioUnitario) 
VALUES (3,'Sierra circular', 'Sierra circular de mano', 999.99);

INSERT INTO articulos (codArticulo, nombreItem, descripcion, precioUnitario) 
VALUES (4,'Cinta métrica', 'Cinta métrica de 10 metros', 79.99);

INSERT INTO articulos (codArticulo, nombreItem, descripcion, precioUnitario) 
VALUES (5,'Llave ajustable', 'Llave ajustable de 10 pulgadas', 199.99);

INSERT INTO clientes (codCliente, nombre, apellido, dni, telefono, direccion, codigoPostal, email) 
VALUES (1,'Juan', 'González', '34567890', '11-2345-6789', 'Rivadavia 123', '1000', 'juangonzalez@hotmail.com');

INSERT INTO clientes (codCliente, nombre, apellido, dni, telefono, direccion, codigoPostal, email) 
VALUES (2,'María', 'López', '23456789', '11-3456-7890', 'Av. Corrientes 456', '2000', 'marialopez@gmail.com');

INSERT INTO clientes (codCliente, nombre, apellido, dni, telefono, direccion, codigoPostal, email) 
VALUES (3,'Carlos', 'Martínez', '45678901', '11-4567-8901', 'Sarmiento 789', '3000', 'carlosmartinez@dla.com');

INSERT INTO clientes (codCliente, nombre, apellido, dni, telefono, direccion, codigoPostal, email) 
VALUES (4,'Laura', 'Fernández', '56789012', '11-5678-9012', 'Av. Belgrano 987', '4000', 'laurafernandez@nestle.com');

INSERT INTO clientes (codCliente, nombre, apellido, dni, telefono, direccion, codigoPostal, email) 
VALUES (5,'Andrés', 'Gómez', '67890123', '11-6789-0123', 'San Martín 654', '5000', 'andresgomez@fibertel.com');

INSERT INTO pedidos (codPedido, codCliente, cantidad, codArticulo, monto, tipoEntrega, fechaPedido) 
VALUES (1,1, 2, 1, 499.98, 'Retira', '2023-06-01');

INSERT INTO pedidos (codPedido, codCliente, cantidad, codArticulo, monto, tipoEntrega, fechaPedido) 
VALUES (2,2, 3, 2, 449.97, 'Envio', '2023-06-02');

INSERT INTO pedidos (codPedido, codCliente, cantidad, codArticulo, monto, tipoEntrega, fechaPedido) 
VALUES (3,3, 1, 3, 999.99, 'Retira', '2023-06-03');

INSERT INTO pedidos (codPedido, codCliente, cantidad, codArticulo, monto, tipoEntrega, fechaPedido) 
VALUES (4,4, 5, 4, 399.95, 'Envio', '2023-06-04');

INSERT INTO pedidos (codPedido, codCliente, cantidad, codArticulo, monto, tipoEntrega, fechaPedido) 
VALUES (5,5, 2, 5, 399.98, 'Retira', '2023-06-05');

