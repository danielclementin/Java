package ar.org.empresa.ferreteria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FerreteriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
