package ar.org.empresa.ferreteria.entities;



public class Articulo {
    private int codArticulo;
    private String nombreItem;
    private String descripcion;
    private float precioUnitario;
    
    public Articulo() {
    }

    public Articulo(int codArticulo, String nombreItem, String descripcion, float precioUnitario) {
        this.codArticulo = codArticulo;
        this.nombreItem = nombreItem;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
    }

    public Articulo(String nombreItem, String descripcion, float precioUnitario) {
        this.nombreItem = nombreItem;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
    }

    

    @Override
    public String toString() {
        return "Articulo [codArticulo=" + codArticulo + ", nombreItem=" + nombreItem + ", descripcion=" + descripcion
                + ", precioUnitario=" + precioUnitario + "]";
    }

    public int getCodArticulo() {
        return codArticulo;
    }

    public void setCodArticulo(int codArticulo) {
        this.codArticulo = codArticulo;
    }

    public String getNombreItem() {
        return nombreItem;
    }

    public void setNombreItem(String nombreItem) {
        this.nombreItem = nombreItem;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    
    
}
