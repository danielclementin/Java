package ar.org.empresa.ferreteria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.empresa.ferreteria.connectors.Connector;
import ar.org.empresa.ferreteria.entities.Articulo;



public class ArticuloRepository {
    private Connection conn = Connector.getConnection();

    public void save(Articulo articulo) {
        if (articulo == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into articulos (nombreItem,descripcion,precioUnitario) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, articulo.getNombreItem());
            ps.setString(2, articulo.getDescripcion());
            ps.setFloat(3, articulo.getPrecioUnitario());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                articulo.setCodArticulo(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Articulo> getAll() {
        List<Articulo> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from articulos")) {
            while (rs.next()) {
                list.add(new Articulo(
                        rs.getInt("codArticulo"), 
                        rs.getString("nombreItem"),
                        rs.getString("descripcion"),
                        rs.getFloat("precioUnitario") 
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Articulo getByCodArticulo(int codArticulo) {
        return getAll()
                .stream()
                .filter(c -> c.getCodArticulo() == codArticulo)
                .findFirst()
                .orElse(new Articulo());
    }

    public List<Articulo>getLikeNombreItem(String nombreItem){
        if(nombreItem==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(c->c.getNombreItem().toLowerCase().contains(nombreItem.toLowerCase()))
                    .toList();   
    }

}
