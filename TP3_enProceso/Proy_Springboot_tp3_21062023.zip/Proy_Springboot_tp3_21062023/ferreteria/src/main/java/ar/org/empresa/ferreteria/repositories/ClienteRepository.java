package ar.org.empresa.ferreteria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.empresa.ferreteria.connectors.Connector;
import ar.org.empresa.ferreteria.entities.Cliente;

public class ClienteRepository {
    private Connection conn = Connector.getConnection();
    
    public void save(Cliente cliente) {
        if (cliente == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into clientes (nombre, apellido, dni, telefono, direccion, codigoPostal, email) values (?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getApellido());
            ps.setString(3, cliente.getDni());
            ps.setString(4, cliente.getTelefono());
            ps.setString(5, cliente.getDireccion());
            ps.setString(6, cliente.getCodigoPostal());
            ps.setString(7, cliente.getTelefono());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                cliente.setCodCliente(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Cliente> getAll() {
        List<Cliente> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from clientes")) {
            while (rs.next()) {
                list.add(new Cliente(
                        rs.getInt("codCliente"),          
                        rs.getString("nombre"),     
                        rs.getString("apellido"),  
                        rs.getString("dni"),         
                        rs.getString("telefono"),
                        rs.getString("direccion"),
                        rs.getString("codigoPostal"),
                        rs.getString("email")    
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Cliente getByCodCliente(int codCliente) {
        return getAll()
                .stream()
                .filter(a -> a.getCodCliente() == codCliente)
                .findFirst()
                .orElse(new Cliente());
    }


    public List<Cliente>getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                    .toList();   
    } 
    
}
