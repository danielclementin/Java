package ar.org.empresa.ferreteria.enums;

public enum TipoEntrega {
    Retira,
    Envio
}
