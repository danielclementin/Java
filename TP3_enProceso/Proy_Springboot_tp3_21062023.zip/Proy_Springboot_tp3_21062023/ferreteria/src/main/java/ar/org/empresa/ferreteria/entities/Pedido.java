package ar.org.empresa.ferreteria.entities;

// import java.sql.Date;


import ar.org.empresa.ferreteria.enums.TipoEntrega;

public class Pedido {
    private int codPedido;
    private int codCliente;
    private int cantidad;
    private int codArticulo;
    private float monto;
    private TipoEntrega tipoEntrega;
    private String fechaPedido;
    
    public Pedido() {
    }


    public Pedido(int codPedido, int codCliente, int cantidad, int codArticulo, float monto, TipoEntrega tipoEntrega, String fechaPedido) {
        this.codPedido = codPedido;
        this.codCliente = codCliente;
        this.cantidad = cantidad;
        this.codArticulo = codArticulo;
        this.monto = monto;
        this.tipoEntrega = tipoEntrega;
        this.fechaPedido = fechaPedido;
    }

    public Pedido(int codCliente, int cantidad, int codArticulo, float monto, TipoEntrega tipoEntrega, String fechaPedido) {
        this.codCliente = codCliente;
        this.cantidad = cantidad;
        this.codArticulo = codArticulo;
        this.monto = monto;
        this.tipoEntrega = tipoEntrega;
        this.fechaPedido = fechaPedido;
    }

    
    


    @Override
    public String toString() {
        return "Pedido [codPedido=" + codPedido + ", codCliente=" + codCliente + ", cantidad=" + cantidad
                + ", codArticulo=" + codArticulo + ", monto=" + monto + ", tipoEntrega=" + tipoEntrega
                + ", fechaPedido=" + fechaPedido + "]";
    }


    public int getCodPedido() {
        return codPedido;
    }

    public void setCodPedido(int codPedido) {
        this.codPedido = codPedido;
    }

    public int getCodCliente() {
        return codCliente;
    }

    public void setCodCliente(int codCliente) {
        this.codCliente = codCliente;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getCodArticulo() {
        return codArticulo;
    }

    public void setCodArticulo(int codArticulo) {
        this.codArticulo = codArticulo;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public TipoEntrega getTipoEntrega() {
        return tipoEntrega;
    }

    public void setTipoEntrega(TipoEntrega tipoEntrega) {
        this.tipoEntrega = tipoEntrega;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    
}
