package ar.org.empresa.ferreteria.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import ar.org.empresa.ferreteria.connectors.Connector;
import ar.org.empresa.ferreteria.entities.Pedido;
import ar.org.empresa.ferreteria.enums.TipoEntrega;

public class PedidoRepository {
    private Connection conn = Connector.getConnection();
    
    public void save(Pedido pedido) {
        if (pedido == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into pedidos (codCliente, cantidad, codArticulo, monto, tipoEntrega, fechaPedido) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, pedido.getCodCliente());
            ps.setInt(2, pedido.getCantidad());
            ps.setInt(3, pedido.getCodArticulo());
            ps.setFloat(4, pedido.getMonto());
            ps.setString(5, pedido.getTipoEntrega().toString());
            ps.setString(6, pedido.getFechaPedido());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                pedido.setCodPedido(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }


    
    public List<Pedido> getAll() {
        List<Pedido> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery("select * from pedidos")) {
            while (rs.next()) {
                list.add(new Pedido(
                        rs.getInt("codPedido"),          
                        rs.getInt("codCliente"),     
                        rs.getInt("cantidad"),  
                        rs.getInt("codArticulo"),         
                        rs.getFloat("monto"),
                        TipoEntrega.valueOf(rs.getString("tipoEntrega")),
                        rs.getString("fechaPedido")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

     public Pedido getByCodPedido(int codPedido) {
        return getAll()
                .stream()
                .filter(a -> a.getCodPedido() == codPedido)
                .findFirst()
                .orElse(new Pedido());
    }


    public Pedido getByCodCliente(int codCliente) {  
        return getAll()
                .stream()
                .filter(a -> a.getCodCliente() == codCliente)
                .findFirst()
                .orElse(new Pedido());
    }

    //REFERENCIA POR SI DEBO usar Listas --- GETLIKECODCLIENTE
    /* public List<Pedido>getByCodCliente(String codCliente){
        if(Integer.parseInt(codCliente)==0) return new ArrayList();
        return getAll()
                    .stream()
                    .filter(pedido -> pedido.getCodCliente() == Integer.parseInt(codCliente))
                    .toList();
    } */

}
