--Consultas

-- Consulta que obtiene la cantidad total de pedidos realizados en cada tipo de entrega: Retira y Envio
SELECT p.tipoEntrega, COUNT(p.codPedido) AS cantidad_pedidos
FROM pedidos p
GROUP BY p.tipoEntrega;

-- Consulta que obtiene el nombre y apellido y el monto total de ventas de los clientes que han realizado pedidos de más de 3 artículos
SELECT c.nombre, c.apellido, SUM(p.monto) AS total_ventas
FROM clientes c
INNER JOIN pedidos p ON c.codCliente = p.codCliente
GROUP BY c.codCliente
HAVING COUNT(p.codArticulo) > 3;

-- Consulta que obtiene el nombre de los artículos y la cantidad de pedidos realizados para cada uno los artículos

SELECT a.nombreItem, COUNT(p.codPedido) AS cantidad_pedidos
FROM articulos a
INNER JOIN pedidos p ON a.codArticulo = p.codArticulo
GROUP BY a.codArticulo;

-- Consulta que obtiene el total de ventas, el nombre y apellido del cliente para todos los pedidos realizados
SELECT c.nombre, c.apellido, SUM(p.monto) AS total_ventas
FROM clientes c
INNER JOIN pedidos p ON c.codCliente = p.codCliente
GROUP BY c.codCliente;

-- Consulta que obtiene nombre y apellido de todos los clientes que han realizado pedidos de Martillo
SELECT c.nombre, c.apellido
FROM clientes c
INNER JOIN pedidos p ON c.codCliente = p.codCliente
INNER JOIN articulos a ON p.codArticulo = a.codArticulo
WHERE a.nombreItem = 'Martillo';

-- Consulta que obtiene todos los pedidos realizados por el cliente 1, incluyendo información del cliente, pedido y artículo

SELECT c.*, p.*, a.*
FROM clientes c
INNER JOIN pedidos p ON c.codCliente = p.codCliente
INNER JOIN articulos a ON p.codArticulo = a.codArticulo
WHERE c.codCliente = 1;